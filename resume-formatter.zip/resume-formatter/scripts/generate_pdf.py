#!/usr/bin/env python3
"""
简历PDF生成脚本
将Markdown格式简历转换为美化的PDF文档
使用内置HTML模板，支持浏览器打印或weasyprint转换
"""

import sys
import os
import re
import subprocess
import tempfile
from datetime import datetime


def get_html_template():
    """获取HTML模板"""
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人简历</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @page {
            size: A4;
            margin: 15mm;
        }
        
        body {
            font-family: "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #2c3e50;
            background: #f5f7fa;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #1a365d 0%, #2b6cb0 100%);
            color: #ffffff;
            padding: 35px 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 12px;
            letter-spacing: 2px;
        }
        
        .header .subtitle {
            font-size: 15px;
            opacity: 0.9;
            font-weight: 300;
        }
        
        .content {
            padding: 25px 35px;
        }
        
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        
        .section:last-child {
            margin-bottom: 0;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1a365d;
            border-bottom: 3px solid #2b6cb0;
            padding-bottom: 8px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        
        .section-title::before {
            content: "";
            display: inline-block;
            width: 5px;
            height: 20px;
            background: #2b6cb0;
            margin-right: 10px;
            border-radius: 3px;
        }
        
        .divider {
            border: none;
            border-top: 2px solid #e2e8f0;
            margin: 20px 0;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
            background: #f7fafc;
            border-radius: 8px;
            overflow: hidden;
            font-size: 14px;
        }
        
        .info-table td {
            padding: 12px 16px;
            border: 1px solid #e2e8f0;
        }
        
        .info-table td:nth-child(odd) {
            background: #edf2f7;
            font-weight: 600;
            color: #4a5568;
            width: 12%;
        }
        
        .info-table td:nth-child(even) {
            color: #2d3748;
        }
        
        .intro-box {
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border-left: 4px solid #2b6cb0;
            padding: 18px 22px;
            border-radius: 0 8px 8px 0;
            line-height: 1.8;
            font-size: 14px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        
        .data-table th {
            background: linear-gradient(135deg, #2b6cb0 0%, #1a365d 100%);
            color: #ffffff;
            padding: 10px 12px;
            text-align: left;
            font-weight: 600;
        }
        
        .data-table th:first-child {
            border-radius: 6px 0 0 0;
        }
        
        .data-table th:last-child {
            border-radius: 0 6px 0 0;
        }
        
        .data-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: top;
        }
        
        .data-table tr:nth-child(even) {
            background: #f7fafc;
        }
        
        .data-table td:first-child {
            width: 45px;
            text-align: center;
            font-weight: 600;
            color: #2b6cb0;
        }
        
        .footer {
            text-align: center;
            padding: 15px;
            color: #718096;
            font-size: 11px;
            border-top: 1px solid #e2e8f0;
            background: #f7fafc;
        }
        
        .highlight {
            color: #2b6cb0;
            font-weight: 600;
        }
        
        @media print {
            body {
                background: #ffffff;
                padding: 0;
            }
            
            .container {
                box-shadow: none;
                border-radius: 0;
            }
            
            .data-table th {
                background: #2b6cb0 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .header {
                background: linear-gradient(135deg, #1a365d 0%, #2b6cb0 100%) !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .info-table td:nth-child(odd) {
                background: #edf2f7 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .section {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{NAME}}</h1>
            <div class="subtitle">{{DIRECTION}}</div>
        </div>
        
        <div class="content">
            {{CONTENT}}
        </div>
        
        <div class="footer">
            生成日期：{{DATE}}
        </div>
    </div>
</body>
</html>'''


def parse_markdown_tables(markdown_text):
    """解析Markdown表格并转换为HTML"""
    lines = markdown_text.split('\n')
    html_parts = []
    current_section = None
    in_table = False
    table_rows = []
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        # 检测分隔线（---）
        if line.startswith('---') and len(line) >= 3:
            i += 1
            continue
        
        # 检测标题
        if line.startswith('### '):
            # 保存之前的表格
            if in_table and table_rows:
                html_parts.append(convert_table_to_html(table_rows, current_section))
                table_rows = []
                in_table = False
                html_parts.append('</div>')
            
            title = line[4:].strip()
            current_section = title
            html_parts.append(f'<div class="section"><h2 class="section-title">{title}</h2>')
            i += 1
            continue
        
        # 检测表格行
        if line.startswith('|') and '|' in line[1:]:
            in_table = True
            # 跳过分隔行
            if re.match(r'^\|[\s\-:|]+\|$', line):
                i += 1
                continue
            table_rows.append(line)
            i += 1
            continue
        
        # 非表格行
        if in_table and table_rows:
            html_parts.append(convert_table_to_html(table_rows, current_section))
            table_rows = []
            in_table = False
            html_parts.append('</div>')
        
        if line and not line.startswith('---'):
            # 处理普通文本（如个人简介）
            if current_section and '个人简介' in current_section:
                html_parts.append(f'<div class="intro-box">{line}</div>')
            elif line:
                html_parts.append(f'<p>{line}</p>')
        
        i += 1
    
    # 处理最后一个表格
    if in_table and table_rows:
        html_parts.append(convert_table_to_html(table_rows, current_section))
        html_parts.append('</div>')
    
    return '\n'.join(html_parts)


def convert_table_to_html(rows, section_name):
    """将Markdown表格行转换为HTML表格"""
    if not rows:
        return ''
    
    # 解析表格
    parsed_rows = []
    for row in rows:
        cells = [cell.strip() for cell in row.split('|')[1:-1]]
        parsed_rows.append(cells)
    
    if not parsed_rows:
        return ''
    
    headers = parsed_rows[0]
    data_rows = parsed_rows[1:] if len(parsed_rows) > 1 else []
    
    # 根据不同section选择表格样式
    if '基本信息' in section_name:
        return format_info_table(headers, data_rows)
    elif '个人简介' in section_name:
        return format_intro_table(data_rows)
    elif any(x in section_name for x in ['学术论文', '书籍著作', '会议演讲', '所获专利', '参与项目', '荣誉认证', '所获奖项']):
        return format_item_list_table(headers, data_rows, section_name)
    else:
        return format_standard_table(headers, data_rows)


def format_info_table(headers, data_rows):
    """格式化基本信息表格"""
    html = ['<table class="info-table">']
    
    for row in data_rows:
        if len(row) >= 4:
            html.append('<tr>')
            html.append(f'<td>{row[0]}</td><td>{row[1]}</td>')
            html.append(f'<td>{row[2]}</td><td>{row[3]}</td>')
            html.append('</tr>')
    
    html.append('</table>')
    return '\n'.join(html)


def format_intro_table(data_rows):
    """格式化个人简介"""
    html = ['<div class="intro-box">']
    for row in data_rows:
        if row and len(row) > 0 and row[0]:
            content = row[0].replace('\\n', '<br>')
            html.append(content)
    html.append('</div>')
    return '\n'.join(html)


def format_item_list_table(headers, data_rows, section_name):
    """格式化项目列表类表格"""
    if not data_rows or all(not any(row) for row in data_rows):
        return ''
    
    html = ['<table class="data-table">']
    html.append('<thead><tr>')
    for h in headers:
        html.append(f'<th>{h}</th>')
    html.append('</tr></thead>')
    
    html.append('<tbody>')
    for idx, row in enumerate(data_rows, 1):
        if not any(row):
            continue
        html.append('<tr>')
        for j, cell in enumerate(row):
            if j == 0:
                html.append(f'<td>{idx}</td>')
            else:
                html.append(f'<td>{cell}</td>')
        html.append('</tr>')
    html.append('</tbody>')
    
    html.append('</table>')
    return '\n'.join(html)


def format_standard_table(headers, data_rows):
    """格式化标准表格"""
    if not data_rows or all(not any(row) for row in data_rows):
        return ''
    
    html = ['<table class="data-table">']
    html.append('<thead><tr>')
    for h in headers:
        html.append(f'<th>{h}</th>')
    html.append('</tr></thead>')
    
    html.append('<tbody>')
    for row in data_rows:
        if not any(row):
            continue
        html.append('<tr>')
        for cell in row:
            html.append(f'<td>{cell}</td>')
        html.append('</tr>')
    html.append('</tbody>')
    
    html.append('</table>')
    return '\n'.join(html)


def extract_name_and_direction(markdown_text):
    """从Markdown中提取姓名和研究方向"""
    name = "个人简历"
    direction = ""
    
    lines = markdown_text.split('\n')
    in_basic_info = False
    
    for i, line in enumerate(lines):
        if '### 基本信息' in line:
            in_basic_info = True
            continue
        
        if in_basic_info and '|' in line:
            cells = [c.strip() for c in line.split('|')[1:-1]]
            if len(cells) >= 2:
                if '姓名' in cells[0]:
                    name = cells[1] if cells[1] else "个人简历"
                elif '研究方向' in cells[0]:
                    direction = cells[1] if cells[1] else ""
                elif len(cells) >= 4:
                    if '姓名' in cells[2]:
                        name = cells[3] if cells[3] else name
                    elif '研究方向' in cells[2]:
                        direction = cells[3] if cells[3] else direction
        
        if in_basic_info and line.startswith('---'):
            break
    
    return name, direction


def markdown_to_html(markdown_text):
    """将Markdown简历转换为美化的HTML"""
    name, direction = extract_name_and_direction(markdown_text)
    content = parse_markdown_tables(markdown_text)
    
    html = get_html_template()
    html = html.replace('{{NAME}}', name)
    html = html.replace('{{DIRECTION}}', direction)
    html = html.replace('{{CONTENT}}', content)
    html = html.replace('{{DATE}}', datetime.now().strftime('%Y年%m月%d日'))
    
    return html


def try_weasyprint(html_content, output_path):
    """尝试使用weasyprint转换PDF"""
    try:
        from weasyprint import HTML
        HTML(string=html_content).write_pdf(output_path)
        return True
    except ImportError:
        return False
    except Exception as e:
        print(f"weasyprint转换失败: {e}")
        return False


def try_wkhtmltopdf(html_content, output_path):
    """尝试使用wkhtmltopdf转换PDF"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
        f.write(html_content)
        html_path = f.name
    
    try:
        result = subprocess.run(
            ['wkhtmltopdf', '--quiet', '--encoding', 'utf-8', 
             '--page-size', 'A4', '--margin-top', '15mm', 
             '--margin-bottom', '15mm', '--margin-left', '15mm', 
             '--margin-right', '15mm', html_path, output_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False
    except Exception as e:
        print(f"wkhtmltopdf转换失败: {e}")
        return False
    finally:
        os.unlink(html_path)


def main():
    if len(sys.argv) < 2:
        print("用法: python generate_pdf.py <markdown文件路径> [输出PDF路径]")
        print("示例: python generate_pdf.py resume.md output.pdf")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else input_file.replace('.md', '.pdf')
    
    # 读取Markdown文件
    if not os.path.exists(input_file):
        print(f"错误: 找不到输入文件: {input_file}")
        sys.exit(1)
    
    with open(input_file, 'r', encoding='utf-8') as f:
        markdown_text = f.read()
    
    # 转换为HTML
    html_content = markdown_to_html(markdown_text)
    
    # 保存HTML文件
    html_file = output_file.replace('.pdf', '.html')
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"HTML文件已生成: {html_file}")
    
    # 尝试转换为PDF
    pdf_generated = False
    
    if try_weasyprint(html_content, output_file):
        print(f"PDF文件已生成(weasyprint): {output_file}")
        pdf_generated = True
    
    if not pdf_generated and try_wkhtmltopdf(html_content, output_file):
        print(f"PDF文件已生成(wkhtmltopdf): {output_file}")
        pdf_generated = True
    
    if not pdf_generated:
        print("提示: 自动PDF转换不可用，请使用以下方式生成PDF:")
        print(f"  1. 在浏览器中打开HTML文件: {html_file}")
        print(f"  2. 按 Ctrl+P (Mac: Cmd+P) 打印")
        print(f"  3. 选择'另存为PDF'保存")


if __name__ == '__main__':
    main()
