#!/usr/bin/env python3
"""
QS排名查询脚本
根据学校名称查询QS 2026排名
"""

import sys
import os
import re


# 常见学校英文名-中文名映射
SCHOOL_NAME_MAP = {
    # 英文名 -> 中文名
    'mit': '麻省理工学院',
    'massachusetts institute of technology': '麻省理工学院',
    'stanford': '斯坦福大学',
    'stanford university': '斯坦福大学',
    'harvard': '哈佛大学',
    'harvard university': '哈佛大学',
    'cambridge': '剑桥大学',
    'university of cambridge': '剑桥大学',
    'oxford': '牛津大学',
    'university of oxford': '牛津大学',
    'caltech': '加州理工大学',
    'california institute of technology': '加州理工大学',
    'princeton': '普林斯顿大学',
    'princeton university': '普林斯顿大学',
    'berkeley': '加州大学伯克利分校',
    'uc berkeley': '加州大学伯克利分校',
    'yale': '耶鲁大学',
    'yale university': '耶鲁大学',
    'columbia': '哥伦比亚大学',
    'columbia university': '哥伦比亚大学',
    'ucl': '伦敦大学学院',
    'university college london': '伦敦大学学院',
    'imperial': '帝国理工学院',
    'imperial college': '帝国理工学院',
    'imperial college london': '帝国理工学院',
    'eth zurich': '苏黎世联邦理工大学',
    'eth': '苏黎世联邦理工大学',
    'nus': '新加坡国立大学',
    'national university of singapore': '新加坡国立大学',
    'ntu': '南洋理工大学',
    'nanyang technological university': '南洋理工大学',
    'tsinghua': '清华大学',
    'tsinghua university': '清华大学',
    'peking university': '北京大学',
    'peking': '北京大学',
    'hkust': '香港科技大学',
    'hk u': '香港大学',
    'hku': '香港大学',
    'university of hong kong': '香港大学',
    'university of toronto': '多伦多大学',
    'u of t': '多伦多大学',
    'mcgill': '麦吉尔大学',
    'mcgill university': '麦吉尔大学',
    'unsw': '新南威尔士大学',
    'university of melbourne': '墨尔本大学',
    'melbourne': '墨尔本大学',
    'university of sydney': '悉尼大学',
    'sydney': '悉尼大学',
    'eth': '苏黎世联邦理工学院',
    'epfl': '洛桑联邦理工学院',
    'tum': '慕尼黑工业大学',
    'technical university of munich': '慕尼黑工业大学',
    'johns hopkins': '约翰霍普金斯大学',
    'cornell': '康奈尔大学',
    'cornell university': '康奈尔大学',
    'university of pennsylvania': '宾夕法尼亚大学',
    'upenn': '宾夕法尼亚大学',
    'ucla': '加州大学洛杉矶分校',
    'university of california los angeles': '加州大学洛杉矶分校',
    'chicago': '芝加哥大学',
    'university of chicago': '芝加哥大学',
}


def load_qs_data(filepath):
    """加载QS排名数据"""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    current_rank = None
    current_university = None
    
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
        
        # 检测排名行（纯数字或=数字格式）
        rank_match = re.match(r'^=?(\d+)$', line)
        if rank_match:
            # 保存前一个学校
            if current_rank and current_university:
                data.append({
                    'rank': int(current_rank),
                    'university': current_university
                })
            current_rank = rank_match.group(1)
            current_university = None
        elif current_rank and not current_university:
            # 这是大学名称行
            current_university = line
    
    # 保存最后一个
    if current_rank and current_university:
        data.append({
            'rank': int(current_rank),
            'university': current_university
        })
    
    return data


def normalize_name(name):
    """规范化学校名称"""
    name = name.lower().strip()
    # 查映射表
    if name in SCHOOL_NAME_MAP:
        return SCHOOL_NAME_MAP[name]
    return name


def search_university(data, query):
    """搜索大学排名"""
    query_lower = query.lower().strip()
    query_normalized = normalize_name(query)
    results = []
    
    for item in data:
        uni = item['university']
        uni_lower = uni.lower()
        
        # 完全匹配
        if query == uni:
            results.append((item, 0))
            continue
        
        # 规范化匹配
        if query_normalized != query_lower:
            if query_normalized in uni or uni in query_normalized:
                results.append((item, 1))
                continue
        
        # 包含匹配
        if query_lower in uni_lower or uni_lower in query_lower:
            results.append((item, 2))
            continue
        
        # 分词匹配（处理学校名变体）
        query_words = set(query_lower.split())
        uni_words = set(uni_lower.split())
        if query_words & uni_words:  # 有交集
            results.append((item, 3))
    
    # 按匹配度和排名排序
    results.sort(key=lambda x: (x[1], x[0]['rank']))
    return [r[0] for r in results]


def format_output(result, top_n=100):
    """格式化输出结果"""
    rank = result['rank']
    if rank <= top_n:
        return f"26年QS **{rank}**"
    elif rank <= 300:
        return f"26年QS {rank}"
    else:
        return f"26年QS {rank} (300+)"


def main():
    if len(sys.argv) < 2:
        print("用法: python query_qs.py <学校名称> [学校名称2 ...]")
        print("示例: python query_qs.py 斯坦福大学")
        print("示例: python query_qs.py MIT 'Stanford University'")
        sys.exit(1)
    
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    qs_file = os.path.join(script_dir, '..', 'references', 'QS排名2026.txt')
    
    if not os.path.exists(qs_file):
        print(f"错误: 找不到QS排名文件: {qs_file}")
        sys.exit(1)
    
    # 加载数据
    data = load_qs_data(qs_file)
    
    # 查询每个学校
    for query in sys.argv[1:]:
        results = search_university(data, query)
        
        if results:
            # 返回最匹配的第一个结果
            best = results[0]
            print(f"{query}: {format_output(best)}")
        else:
            # 未找到
            print(f"{query}: 未找到")


if __name__ == '__main__':
    main()
