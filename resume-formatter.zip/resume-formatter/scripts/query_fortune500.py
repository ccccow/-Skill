#!/usr/bin/env python3
"""
世界500强查询脚本
根据公司名称查询是否在世界500强榜单中
"""

import sys
import os
import re


# 常见公司英文名-繁体中文名映射（世界500强文件使用繁体中文）
COMPANY_NAME_MAP = {
    # 科技公司
    'apple': '蘋果',
    'microsoft': '微軟',
    'google': 'Alphabet',  # Google母公司
    'alphabet': 'Alphabet',
    'meta': 'Meta',
    'facebook': 'Meta',
    'amazon': '亞馬遜',
    'tesla': '特斯拉',
    'nvidia': '輝達',
    'oracle': '甲骨文',
    'cisco': '思科系統',
    'intel': '英特爾',
    'ibm': 'IBM',
    'samsung': '三星電子',
    'sony': '索尼',
    'tencent': '騰訊控股',
    'alibaba': '阿裏巴巴集團',
    'alibaba group': '阿裏巴巴集團',
    'baidu': '百度',
    'bytedance': '字節跳動',
    'tsmc': '台積電',
    'taiwan semiconductor': '台積電',
    
    # 金融公司
    'jpmorgan': '摩根大通',
    'jp morgan': '摩根大通',
    'jpmorgan chase': '摩根大通',
    'morgan stanley': '摩根士丹利',
    'goldman sachs': '高盛集團',
    'goldman': '高盛集團',
    'citi': '花旗集團',
    'citigroup': '花旗集團',
    'bank of america': '美國銀行',
    'wells fargo': '富國銀行',
    'hsbc': '匯豐控股',
    'icbc': '中國工商銀行',
    'industrial and commercial bank of china': '中國工商銀行',
    'china construction bank': '中國建設銀行',
    'agricultural bank of china': '中國農業銀行',
    'bank of china': '中國銀行',
    
    # 能源公司
    'exxonmobil': '埃克森美孚',
    'exxon': '埃克森美孚',
    'shell': '殼牌',
    'chevron': '雪佛龍',
    'bp': 'BP',
    'total': '道達爾能源',
    'totalenergies': '道達爾能源',
    'aramco': '沙特阿美',
    'saudi aramco': '沙特阿美',
    
    # 零售/消费品
    'walmart': '沃爾瑪',
    'costco': '開市客',
    'amazon': '亞馬遜',
    'coca-cola': '可口可樂',
    'coca cola': '可口可樂',
    'pepsico': '百事公司',
    'pepsi': '百事公司',
    'nestle': '雀巢公司',
    'procter & gamble': '寶潔',
    'p&g': '寶潔',
    'lvmh': '路威酩軒',
    
    # 汽车
    'toyota': '豐田汽車',
    'volkswagen': '大衆集團',
    'vw': '大衆集團',
    'mercedes': '梅賽德斯-奔馳集團',
    'mercedes-benz': '梅賽德斯-奔馳集團',
    'bmw': '寶馬集團',
    'ford': '福特汽車',
    'gm': '通用汽車',
    'general motors': '通用汽車',
    'honda': '本田汽車',
    
    # 医药
    'pfizer': '輝瑞制藥',
    'johnson & johnson': '瓊森',
    'j&j': '瓊森',
    'merck': '默克集團',
    'abbvie': '艾伯維',
    'novartis': '諾華',
    'roche': '羅氏',
    'sanofi': '賽諾菲',
    
    # 其他
    'disney': '華特迪斯尼',
    'walmart': '沃爾瑪',
    'ups': '聯合包裹服務（UPS）',
    'fedex': '聯邦快遞',
    'at&t': 'AT&T',
    'verizon': '威瑞森通信',
    
    # 中国公司简体->繁体映射
    '中国工商银行': '中國工商銀行',
    '中国建设银行': '中國建設銀行',
    '中国农业银行': '中國農業銀行',
    '中国银行': '中國銀行',
    '中国移动': '中國移動',
    '中国石化': '中國石化',
    '中国石油': '中國石油',
    '腾讯': '騰訊控股',
    '腾讯控股': '騰訊控股',
    '阿里巴巴': '阿裏巴巴集團',
    '阿里巴巴集团': '阿裏巴巴集團',
    '苹果公司': '蘋果',
    '微软': '微軟',
    '特斯拉': '特斯拉',
    '台积电': '台積電',
    '比亚迪': '比亞迪',
}


def load_fortune500_data(filepath):
    """加载世界500强数据"""
    data = []
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('序号'):
            continue
        
        # 解析格式: 序号\t企業名稱\t國家或地區
        parts = line.split('\t')
        if len(parts) >= 2:
            rank_str = parts[0].strip()
            company = parts[1].strip()
            
            # 处理并列排名
            rank_match = re.match(r'^=?(\d+)$', rank_str)
            if rank_match:
                data.append({
                    'rank': int(rank_match.group(1)),
                    'company': company
                })
    
    return data


def normalize_company_name(name):
    """规范化公司名称"""
    name_lower = name.lower().strip()
    # 查映射表
    if name_lower in COMPANY_NAME_MAP:
        return COMPANY_NAME_MAP[name_lower]
    # 简体转繁体查表
    if name in COMPANY_NAME_MAP:
        return COMPANY_NAME_MAP[name]
    return name


def search_company(data, query):
    """搜索公司"""
    query_lower = query.lower().strip()
    query_normalized = normalize_company_name(query)
    results = []
    
    for item in data:
        company = item['company']
        company_lower = company.lower()
        
        # 完全匹配
        if query == company:
            results.append((item, 0))
            continue
        
        # 规范化匹配
        if query_normalized != query:
            if query_normalized == company:
                results.append((item, 0))
                continue
            if query_normalized in company or company in query_normalized:
                results.append((item, 1))
                continue
        
        # 包含匹配
        if query_lower in company_lower or company_lower in query_lower:
            results.append((item, 2))
            continue
        
        # 分词匹配
        query_words = set(query_lower.split())
        company_words = set(company_lower.split())
        if query_words & company_words:  # 有交集
            results.append((item, 3))
    
    # 按匹配度和排名排序
    results.sort(key=lambda x: (x[1], x[0]['rank']))
    return [r[0] for r in results]


def main():
    if len(sys.argv) < 2:
        print("用法: python query_fortune500.py <公司名称> [公司名称2 ...]")
        print("示例: python query_fortune500.py 苹果")
        print("示例: python query_fortune500.py Apple Microsoft")
        sys.exit(1)
    
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    fortune_file = os.path.join(script_dir, '..', 'references', '世界500强2025.txt')
    
    if not os.path.exists(fortune_file):
        print(f"错误: 找不到世界500强文件: {fortune_file}")
        sys.exit(1)
    
    # 加载数据
    data = load_fortune500_data(fortune_file)
    
    # 查询每个公司
    for query in sys.argv[1:]:
        results = search_company(data, query)
        
        if results:
            best = results[0]
            print(f"{query}: 25年世界500强 第{best['rank']}名")
        else:
            print(f"{query}: 未在世界500强榜单中")


if __name__ == '__main__':
    main()
